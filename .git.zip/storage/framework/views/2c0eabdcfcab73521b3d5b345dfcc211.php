<?php $__env->startSection('content'); ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Data Peminjaman Lab</h1>
    <a href="<?php echo e(route('peminjaman.create')); ?>" class="btn btn-sm btn-primary shadow-sm">
        <i class="fas fa-plus mr-1"></i> Tambah Peminjaman
    </a>
</div>

<div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered text-sm" width="100%">
                <thead class="thead-light">
                    <tr>
                        <th width="5%">No</th>
                        <th>Peminjam</th>
                        <th>Laboratorium</th>
                        <th>Tanggal Pinjam</th>
                        <th>Keperluan</th>
                        <th>Status</th>
                        <th width="20%">Aksi / ACC</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $peminjamans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($p->nama_peminjam); ?></td>
                            <td><?php echo e($p->lab->nama_lab ?? '-'); ?></td>
                            <td><?php echo e($p->tanggal_pinjam); ?></td>
                            <td><?php echo e($p->keperluan); ?></td>
                            <td>
                                <?php if($p->status == 'Disetujui'): ?>
                                    <span class="badge badge-success">Disetujui</span>
                                <?php elseif($p->status == 'Ditolak'): ?>
                                    <span class="badge badge-danger">Ditolak</span>
                                <?php else: ?>
                                    <span class="badge badge-warning">Pending</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <!-- Tombol ACC/Reject untuk Admin -->
                                <form action="<?php echo e(route('peminjaman.updateStatus', $p->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="status" value="Disetujui">
                                    <button class="btn btn-sm btn-success" title="Setujui"><i class="fas fa-check"></i></button>
                                </form>

                                <form action="<?php echo e(route('peminjaman.updateStatus', $p->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="status" value="Ditolak">
                                    <button class="btn btn-sm btn-secondary" title="Tolak"><i class="fas fa-times"></i></button>
                                </form>

                                <form action="<?php echo e(route('peminjaman.destroy', $p->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus data peminjaman?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center py-3">Belum ada data peminjaman lab.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projek framework\laragon-6.0-minimal\www\fahri-labreserve\resources\views/admin/peminjaman/index.blade.php ENDPATH**/ ?>